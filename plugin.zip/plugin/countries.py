def countries():
    return [
        {"country": "Algeria", "tax_rate": "3"},
        {"country": "India", "tax_rate": "6"},
        {"country": "Nigeria", "tax_rate": "2"},
        {"country": "United States", "tax_rate": "7"},
    ]
